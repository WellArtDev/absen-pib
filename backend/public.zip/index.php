<?php
/**
 * AbsenPIB — Root Entry Point
 * https://api-pib.wella.cloud/ → langsung tampil login page
 * /api/xxx → API JSON
 */

$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = '/' . trim($uri, '/');

// Serve uploaded files
if (str_starts_with($uri, '/uploads/')) {
    $file = __DIR__ . $uri;
    if (file_exists($file)) {
        header('Content-Type: ' . mime_content_type($file));
        header('Cache-Control: public, max-age=31536000');
        readfile($file);
        exit;
    }
    http_response_code(404);
    exit;
}

// Root & dashboard pages → serve HTML
if ($uri === '/' || $uri === '/dashboard' || str_starts_with($uri, '/dashboard/') || str_starts_with($uri, '/api/')) {
    $_SERVER['ORIGINAL_REQUEST_URI'] = $uri;
    require __DIR__ . '/public/index.php';
    exit;
}

// Static files
$publicFile = __DIR__ . '/public' . $uri;
if (file_exists($publicFile) && !is_dir($publicFile)) {
    $ext = pathinfo($publicFile, PATHINFO_EXTENSION);
    $mime = match($ext) {
        'css' => 'text/css', 'js' => 'application/javascript',
        'png' => 'image/png', 'jpg','jpeg' => 'image/jpeg',
        'svg' => 'image/svg+xml', 'ico' => 'image/x-icon',
        default => mime_content_type($publicFile)
    };
    header('Content-Type: ' . $mime);
    readfile($publicFile);
    exit;
}

// Fallback: API routing
require __DIR__ . '/public/index.php';
