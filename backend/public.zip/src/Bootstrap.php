<?php
declare(strict_types=1);

namespace App;

use Dotenv\Dotenv;

class Bootstrap
{
    public static function init(): void
    {
        // Load .env
        $dotenv = Dotenv::createImmutable(__DIR__ . '/..');
        $dotenv->safeLoad();

        // Error handling
        error_reporting(E_ALL);
        ini_set('display_errors', '0');
        ini_set('log_errors', '1');

        set_exception_handler(function (\Throwable $e) {
            http_response_code(500);
            echo json_encode([
                'success' => false,
                'error' => $_ENV['NODE_ENV'] === 'development' ? $e->getMessage() : 'Internal Server Error'
            ]);
        });
    }
}
