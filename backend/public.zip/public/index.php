<?php
declare(strict_types=1);

require_once __DIR__ . '/../vendor/autoload.php';

use App\Bootstrap;
use App\Router;
use App\Response;

Bootstrap::init();

$method = $_SERVER['REQUEST_METHOD'];
$rawUri = $_SERVER['ORIGINAL_REQUEST_URI'] ?? $_SERVER['REQUEST_URI'] ?? '/';
$uri = strtok($rawUri, '?');
$uri = '/' . trim($uri, '/');
$body = json_decode(file_get_contents('php://input'), true) ?? [];
$query = $_GET;

// ─── Root → dashboard login page ─────────────────
if ($uri === '/' || $uri === '') {
    header('Content-Type: text/html; charset=utf-8');
    require __DIR__ . '/dashboard/index.php';
    exit;
}

// ─── Dashboard pages (HTML) ──────────────────────
if ($uri === '/dashboard') {
    header('Location: /dashboard/');
    exit;
}
if (str_starts_with($uri, '/dashboard/')) {
    $page = basename($uri);
    $file = __DIR__ . '/dashboard/' . ($page ?: 'index.php');
    if ($page && str_ends_with($page, '.css') || str_ends_with($page, '.js')) {
        // No assets in dashboard folder — ignore
        http_response_code(404);
        exit;
    }
    if ($page && file_exists($file) && !is_dir($file)) {
        // Forward to dashboard PHP file
        header('Content-Type: text/html; charset=utf-8');
        $_SERVER['SCRIPT_FILENAME'] = $file;
        require $file;
        exit;
    }
    // Dashboard root
    header('Content-Type: text/html; charset=utf-8');
    require __DIR__ . '/dashboard/index.php';
    exit;
}

// ─── /api prefix → strip dan lanjut ke API ───────
if (str_starts_with($uri, '/api')) {
    $uri = substr($uri, 4);
    if ($uri === '' || $uri === '/') $uri = '/';
    // Recurse for root after /api strip
    if ($uri === '/' || $uri === '') {
        header('Content-Type: text/html; charset=utf-8');
        require __DIR__ . '/dashboard/index.php';
        exit;
    }
}

// ─── JSON REST API ───────────────────────────────
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($method === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$router = new Router();
require_once __DIR__ . '/../src/routes.php';
$router->dispatch($method, $uri, $body, $query);
