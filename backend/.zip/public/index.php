<?php
declare(strict_types=1);

// ─── Manual autoload (no composer PSR-4 needed) ──
$SRC = __DIR__ . '/../src';
require_once $SRC . '/Bootstrap.php';
require_once $SRC . '/Database.php';
require_once $SRC . '/Response.php';
require_once $SRC . '/Auth.php';
require_once $SRC . '/Middleware.php';
require_once $SRC . '/Router.php';
// Utils
require_once $SRC . '/utils/Validator.php';
require_once $SRC . '/utils/ImageUpload.php';
require_once $SRC . '/utils/AntiFakeGps.php';
require_once $SRC . '/utils/CsvExport.php';
require_once $SRC . '/utils/Notification.php';
// Controllers
require_once $SRC . '/controllers/AuthController.php';
require_once $SRC . '/controllers/AttendanceController.php';
require_once $SRC . '/controllers/OvertimeController.php';
require_once $SRC . '/controllers/LeaveController.php';
require_once $SRC . '/controllers/AdminController.php';
require_once $SRC . '/controllers/CompanyController.php';
require_once $SRC . '/controllers/OfficeController.php';
require_once $SRC . '/controllers/ReportController.php';
require_once $SRC . '/controllers/NotificationController.php';

use App\Bootstrap;
use App\Router;

// Load vendor (dotenv only)
$vendorAutoload = __DIR__ . '/../vendor/autoload.php';
if (file_exists($vendorAutoload)) {
    require_once $vendorAutoload;
}

Bootstrap::init();

$method = $_SERVER['REQUEST_METHOD'];
$uri = strtok($_SERVER['REQUEST_URI'] ?? '/', '?');
$uri = '/' . trim($uri, '/');
$body = json_decode(file_get_contents('php://input'), true) ?? [];
$query = $_GET;

// ─── Root: login page ──────────────────────────────
if ($uri === '/') {
    header('Content-Type: text/html; charset=utf-8');
    require __DIR__ . '/dashboard/index.php';
    exit;
}

// ─── Dashboard HTML pages ──────────────────────────
if (str_starts_with($uri, '/dashboard')) {
    if ($uri === '/dashboard') { header('Location: /dashboard/'); exit; }
    $seg = basename($uri) ?: 'index.php';
    $file = __DIR__ . '/dashboard/' . $seg;
    if (is_file($file) && pathinfo($file, PATHINFO_EXTENSION) === 'php') {
        header('Content-Type: text/html; charset=utf-8');
        require $file;
        exit;
    }
    header('Content-Type: text/html; charset=utf-8');
    require __DIR__ . '/dashboard/index.php';
    exit;
}

// ─── API: /api prefix ──────────────────────────────
if (!str_starts_with($uri, '/api/')) {
    header('Content-Type: application/json; charset=utf-8');
    http_response_code(404);
    echo json_encode(['success' => false, 'error' => 'Not found. Use /api/auth/login, /api/attendance/check-in, etc.']);
    exit;
}

$apiUri = '/' . trim(substr($uri, 4), '/') ?: '/';

// ─── JSON API output ───────────────────────────────
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($method === 'OPTIONS') {
    http_response_code(200);
    exit;
}

$router = new Router();
require_once $SRC . '/routes.php';
$router->dispatch($method, $apiUri, $body, $query);
