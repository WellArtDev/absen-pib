<?php
/**
 * AbsenPIB — Single Entry Point
 *
 * https://api-pib.wella.cloud/          → dashboard login page
 * https://api-pib.wella.cloud/dashboard/ → web dashboard
 * https://api-pib.wella.cloud/api/*     → REST API (JSON)
 *
 * .htaccess routes ALL requests that don't exist as files here.
 */

// ─── Root: same as public/index.php ────────────────
require __DIR__ . '/public/index.php';
